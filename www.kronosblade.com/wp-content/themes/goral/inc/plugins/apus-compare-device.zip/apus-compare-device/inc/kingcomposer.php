<?php

add_action('init', 'apus_compare_device_elements_kingcomposer_map', 99 );

function apus_compare_device_elements_kingcomposer_map() {
	global $kc;
	$maps = array();

	$maps['element_compare_device'] =  apply_filters( 'apus_themer_kingcomposer_map_element_compare_device', array(
		'name' => esc_html__( 'Apus Compare Devices', 'apus-themer' ),
		'title' => esc_html__( 'Apus Compare Devices Settings', 'apus-themer' ),
		'icon' => 'fa fa-newspaper-o',
		'category' => 'Elements',
		'wrapper_class' => 'clearfix',
		'params' => array(
            array(
                'name' => 'title',
                'label' => esc_html__( 'Title' ,'apus-themer' ),
                'type' => 'text',
                "admin_label" => true,
            ),
		)
	));

    $kc->add_map( $maps );
}

function apus_compare_device_set_template_path(){
	global $kc;  
	
	$kc->set_template_path( APUSCOMPAREDEVICE_PLUGIN_DIR . 'templates/' );
	$kc->set_template_path( get_template_directory() . '/kingcomposer/' );
}
add_action('init', 'apus_compare_device_set_template_path' , 99 );