<?php
/**
 * device post type
 *
 * @package    apus-compare-device
 * @author     ApusTheme <apusthemes@gmail.com >
 * @license    GNU General Public License, version 3
 * @copyright  13/06/2016 ApusTheme
 */
 
if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly
}
class ApusCompareDevice_PostType_Device{

	/**
	 * init action and filter data to define resource post type
	 */
	public static function init() {
		add_action( 'init', array( __CLASS__, 'definition' ) );
		add_filter( 'cmb2_meta_boxes', array( __CLASS__, 'metaboxes' ) );
	}
	/**
	 *
	 */
	public static function definition() {
		
		$labels = array(
			'name'                  => __( 'Compare Devices', 'apus-compare-device' ),
			'singular_name'         => __( 'Device', 'apus-compare-device' ),
			'add_new'               => __( 'Add New Device', 'apus-compare-device' ),
			'add_new_item'          => __( 'Add New Device', 'apus-compare-device' ),
			'edit_item'             => __( 'Edit Device', 'apus-compare-device' ),
			'new_item'              => __( 'New Device', 'apus-compare-device' ),
			'all_items'             => __( 'All Devices', 'apus-compare-device' ),
			'view_item'             => __( 'View Device', 'apus-compare-device' ),
			'search_items'          => __( 'Search Device', 'apus-compare-device' ),
			'not_found'             => __( 'No Devices found', 'apus-compare-device' ),
			'not_found_in_trash'    => __( 'No Devices found in Trash', 'apus-compare-device' ),
			'parent_item_colon'     => '',
			'menu_name'             => __( 'Compare Devices', 'apus-compare-device' ),
		);

		$labels = apply_filters( 'apuscomparedevice_postype_device_labels' , $labels );

		register_post_type( 'apus-device',
			array(
				'labels'            => $labels,
				'supports'          => array( 'title', 'thumbnail' ),
				'public'            => false,
				'has_archive'       => false,
				'show_ui'           => true,
				'categories'        => array(),
				'menu_position'     => 51,
			)
		);
	}
	
	/**
	 *
	 */
	public static function metaboxes( array $metaboxes ) {
		$prefix = 'apus_compare_device_';
		
		$metaboxes[ $prefix . 'info' ] = array(
			'id'                        => $prefix . 'info',
			'title'                     => __( 'Device Information', 'apus-simple-event' ),
			'object_types'              => array( 'apus-device' ),
			'context'                   => 'normal',
			'priority'                  => 'high',
			'show_names'                => true,
			'fields'                    => array(
				array(
				    'name' => __( 'Device Link', 'apus-simple-event' ),
				    'id'   => $prefix.'link',
				    'type' => 'text'
				),
			)
		);
		
		return $metaboxes;
	}
}

ApusCompareDevice_PostType_Device::init();