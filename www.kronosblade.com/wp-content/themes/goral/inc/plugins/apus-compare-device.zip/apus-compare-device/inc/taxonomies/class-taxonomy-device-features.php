<?php
/**
 * event category
 *
 * @package    apus-compare-device
 * @author     ApusTheme <apusthemes@gmail.com >
 * @license    GNU General Public License, version 3
 * @copyright  13/06/2016 ApusTheme
 */
 
if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly
}
class ApusCompareDevice_Taxonomy_Device_Features{

	/**
	 *
	 */
	public static function init() {
		add_action( 'init', array( __CLASS__, 'definition' ) );
	}

	/**
	 *
	 */
	public static function definition() {
		$labels = array(
			'name'              => __( 'Device Features', 'apus-compare-device' ),
			'singular_name'     => __( 'Device Feature', 'apus-compare-device' ),
			'search_items'      => __( 'Search Device Features', 'apus-compare-device' ),
			'all_items'         => __( 'All Device Features', 'apus-compare-device' ),
			'parent_item'       => __( 'Parent Device Feature', 'apus-compare-device' ),
			'parent_item_colon' => __( 'Parent Device Feature:', 'apus-compare-device' ),
			'edit_item'         => __( 'Edit Device Feature', 'apus-compare-device' ),
			'update_item'       => __( 'Update Device Feature', 'apus-compare-device' ),
			'add_new_item'      => __( 'Add New Device Feature', 'apus-compare-device' ),
			'new_item_name'     => __( 'New Device Feature', 'apus-compare-device' ),
			'menu_name'         => __( 'Device Features', 'apus-compare-device' ),
		);

		register_taxonomy( 'device-features', 'apus-device', array(
			'labels'            => apply_filters( 'apuscomparedevice_taxomony_device_feature_labels', $labels ),
			'hierarchical'      => true,
			'query_var'         => 'device-features',
			'rewrite'           => array( 'slug' => __( 'device-features', 'apus-compare-device' ) ),
			
			'public'            => false,
			'has_archive'       => false,
			'show_ui'           => true,
		) );
	}
}

ApusCompareDevice_Taxonomy_Device_Features::init();