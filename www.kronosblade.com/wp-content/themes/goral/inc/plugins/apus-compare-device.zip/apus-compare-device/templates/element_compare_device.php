<?php

$atts  = array_merge( array(
	'title'  => '',
), $atts);
extract( $atts );

$terms = get_terms( array(
    'taxonomy' => 'device-features',
    'hide_empty' => false,
    'orderby' => 'term_id',
    'order' => 'ASC'
) );

$args = array(
	'posts_per_page'   => -1,
	'post_type'        => 'apus-device',
	'post_status'      => 'publish',
	'orderby'          => 'date',
	'order'            => 'DESC'
);
$posts = get_posts( $args );
$term_ids = array();
?>
<div class="widget widget-compare-device">
	<h3 class="widget-title"><?php echo esc_html($title); ?></h3>
	<div class="widget-content">
		<table>
			<thead>
				<tr>
					<td></td>
					<?php foreach ($posts as $post) { ?>
						<td>
							<?php if ( has_post_thumbnail( $post->ID ) ) {
								$link = get_post_meta($post->ID, 'apus_compare_device_link', true);
								?>
								<div class="post-thumb">
									<?php if ($link) { ?>
										<a href="<?php echo esc_url($link); ?>">
									<?php } ?>
										<?php echo get_the_post_thumbnail( $post->ID, 'full' ); ?>
									<?php if ($link) { ?>
										</a>
									<?php } ?>
								</div>
								<?php
							}
							?>
							<h3 class="name-title">
								<?php if ($link) { ?>
									<a href="<?php echo esc_url($link); ?>">
								<?php }
									echo trim($post->post_title);
								if ($link) { ?>
									</a>
								<?php } ?>
							</h3>
						</td>
						<?php
							$terms_post = wp_get_post_terms( $post->ID, 'device-features' );
							if ($terms_post) {
								foreach ($terms_post as $term) {
									$term_ids[$post->ID][] = $term->term_id;
								}
							}
						?>
					<?php } ?>
				</tr>
			</thead>
			<tbody>
				<?php foreach ($terms as $term) { ?>
					<tr>
						<td><?php echo trim($term->name); ?></td>
						<?php foreach ($posts as $post) { ?>
							<td><?php echo (isset($term_ids[$post->ID]) && in_array($term->term_id, $term_ids[$post->ID]) ? esc_html__('Yes', 'apus-compare-device') : esc_html__('', 'apus-compare-device') ); ?></td>
						<?php } ?>
					</tr>
				<?php } ?>
			</tbody>
		</table>
	</div>
</div>
